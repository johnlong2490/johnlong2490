---
name: Feature request
about: Suggest an idea for this project

---

**Feature Request Description**

<!-- Describe your feature request for iaito only using ascii and jpegs only -->

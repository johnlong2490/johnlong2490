Developer Documentation
=======================

.. note::
   New to Iaito development? Check out our :doc:`tutorial for new developers <code/getting-started>`.

.. toctree::
   :maxdepth: 2
   :glob:

   Getting Started <code/getting-started>
   code/development-guidelines
   code/ide-setup
   code/*

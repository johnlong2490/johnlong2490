Translate Iaito
==================

Help Iaito by adding translations to the project!

Iaito is a global project with users from all around the world. We believe that Iaito should be as accessible as possible, and want our users to feel comfortable while using its interface. Providing our community an interface with their own language makes the experience of using Iaito better. Thus, Iaito supports a translation and localization mechanism powered by the `Crowdin <https://crowdin.com/project/cutter>`_ platform. We invite you to contribute and add translations to the project.


.. important::
  We currently support more than 15 languages. If you need to add a language that isn't available yet, ask any developer from the team and they will happily assist you.

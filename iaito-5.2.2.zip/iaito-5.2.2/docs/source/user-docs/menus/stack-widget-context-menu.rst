Stack Widget Context Menu 
==============================


Edit Stack Value
----------------------------------------
**Description:** Edit the value of the current stack item using a dialog. 

**Steps:** Right-click on an item in the Stack widget and choose ``Edit stack value...`` to open the edit dialog.